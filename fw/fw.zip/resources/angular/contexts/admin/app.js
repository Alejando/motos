var setpoint = angular.module('setpoint', [
    'ngRoute',
    'datatables',
    'ui.tinymce',
    'color.picker',
    'jsTree.directive',
    'ngSanitize',
    'ui.select',
    'slugifier',
    'fiestah.money',
    'ui.bootstrap',
    'rzModule',
    'ui.bootstrap.datetimepicker',
    'remoteValidation',
    'devtics-angular-modelbase'
]);
//setpoint.constat('Config', {
//    DATE_FORMAT : 'dd/MMMM/yyyy', //https://docs.angularjs.org/api/ng/filter/date
//    HOUR_FORMAT : 'HH:mm:ss',
//    DATE_SERVER_FORMAT : 'yyyy-MM-ddTHH:mm:ssZ',
//    CALENDAR_DATE_FORMAT : 'dd/MM/yyyy' //http://bootstrap-datepicker.readthedocs.org/en/stable/options.html#format
//});
