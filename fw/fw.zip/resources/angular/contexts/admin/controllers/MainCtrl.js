setpoint.controller('MainCtrl', function ($scope) {
//    $scope.mensaje = "hola mundo"; 
//    console.log("mainController");    
});
