setpoint.controller('HomeCtrl', function ($scope) {
    $scope.msj = "Bienvenido ";    
//    console.log("mainController") ;    
});