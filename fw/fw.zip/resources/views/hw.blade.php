@extends('layouts.app')
@section('content')
    <H1>{{$msj}}</h1>
@stop