@extends('mails.frames.common')
@section('message')
<h1>HTML trace payment</h1>
@stop