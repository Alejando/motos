@extends('mails.frames.common')
@section('message')
<h1>Contacto Bounce</h1>
@stop