@extends('mails.frames.common')
@section('message')
    Revision de pago
@stop