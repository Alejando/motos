@extends('mails.frames.common')
@section('message')
    Confirmación pago!
@stop