@extends('mails.frames.common')
@section('message')
    Contacto Bounce!
@stop