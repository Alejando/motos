@extends('mails.frames.common')
@section('message')
    Recuperar password
@stop