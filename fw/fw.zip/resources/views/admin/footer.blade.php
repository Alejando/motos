<footer class="footer text-right">
    <div style="float:left">{{date('Y')}} © Bounce.</div>
    <div style="float:right">Desarrollado Web <a href="http://estrasol.com.mx" target="_blank">Estrasol</a></div>
</footer>