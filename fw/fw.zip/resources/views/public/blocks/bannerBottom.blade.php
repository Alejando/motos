<!--div class="banner">
    <img src="{{asset('img/agassi.png')}}">
    <div>Andre Agassi</div>
</div-->

<div class="cajaestrella margentop30">
    <img src="{{ asset('img/agassi.png') }}" />
    <h2>Andre Agassi</h2>
</div>