@extends('public.base')
@section('body')
<div>
    <div class="address-map">
        <a href="https://goo.gl/maps/iRRgwiDNTcy" target="_blank">
            <img border="0" class="address-img" src="//maps.googleapis.com/maps/api/staticmap?center=20.6293307,-103.4404401&zoom=16&size=1000x500&markers=color:red|20.6293307,-103.4404401&key=AIzaSyBimYo3oz8Evj6Z-TYA01ncmpArptMg4Uk" alt="">
        </a>
    </div>

    <div class="address-content">
        <h2>Dirección</h2>
        Prol. Mariano Otero 680<br>
        Mariano Otero<br>
        Zapopan, Jalisco<br>
        México<br>
        C.P. 45067<br><br>
        <b>Teléfono: (33) 3336 7487</b><br>
        <br><br>
        Horario: Lunes a Viernes<br>
        de 9am a 8pm<br>
        (horario corrido)
    </div>
</div>
@stop