<?php
namespace DwSetpoint\Libs\Facades;
class Helpers  extends \Illuminate\Support\Facades\Facade{
    protected static function getFacadeAccessor() { return 'helpers'; }
}
