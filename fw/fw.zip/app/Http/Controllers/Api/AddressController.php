<?php

namespace DwSetpoint\Http\Controllers\Api;
class AddressController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Address::class;
}