<?php

namespace DwSetpoint\Http\Controllers\Api;
class StateController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\State::class;
}