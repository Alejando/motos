<?php

namespace DwSetpoint\Http\Controllers\Api;
class CountryController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Country::class;
}