<?php


namespace DwSetpoint\Http\Controllers\Api;
class SizeController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Size::class;
}