<?php

namespace DwSetpoint\Http\Controllers\Api;
class ProfileController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Profile::class;
}