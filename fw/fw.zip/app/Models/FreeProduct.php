<?php

namespace DwSetpoint\Models;

use Illuminate\Database\Eloquent\Model;

class FreeProduct extends \DevTics\LaravelHelpers\Model\ModelBase {
    //
}
