<?php
namespace DwSetpoint\Models;
class Profile  extends \DevTics\LaravelHelpers\Model\ModelBase{
    
}