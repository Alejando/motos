<script src="<?php echo e(asset('/js/bower_components/jquery/dist/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/bower_components/jquery-ui/jquery-ui.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/bower_components/owlcarousel/owl-carousel/owl.carousel.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bower_components/angular/angular.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bower_components/angular-slugify/angular-slugify.js')); ?>"  type="text/javascript"></script>
<script src="<?php echo e(asset('js/bower_components/angular-owl-carousel/src/angular-owl-carousel.js')); ?>"  type="text/javascript"></script>
<script src="<?php echo e(asset('js/bower_components/bootstrap3-dialog/dist/js/bootstrap-dialog.min.js')); ?>"  type="text/javascript"></script>
<script src="<?php echo e(asset('js/bower_components/devticstools-ng-factory-modelbase-for-laravel/src/baseModel.js')); ?>"  type="text/javascript"></script>
<script src="<?php echo e(asset('js/laroute.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/generico.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/bower_components/angular-local-storage/dist/angular-local-storage.min.js')); ?>"  type="text/javascript"></script>
<script src="<?php echo e(asset('js/estrasol/web-angular.js')); ?>" type="text/javascript"></script>
<?php echo $__env->yieldContent('scripts'); ?>