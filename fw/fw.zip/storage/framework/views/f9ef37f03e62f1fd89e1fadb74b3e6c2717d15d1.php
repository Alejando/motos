<div class="col-md-3 col-sm-4 col-xs-12" ng-controller="ProductListCtrl">
    <div class="item">
        <div class="producto">
            <a href="<?php echo e($product->getURL(isset($categorySlug)?$categorySlug:'general')); ?>">
                <div class="productohover">
                    <div class="productotable">
                        <div>
                            <span  ng-class="{btnkon: checkFav(<?php echo e($product->id); ?>)}" class="btnk" ng-click="addBookmark($event, <?php echo e($product->id); ?>)"></span>
                            <h3>$000.00</h3>
                        <span href="" class="btnc"></span>
                        </div>
                    </div>
                </div>
            </a>
            <?php if($product->discount_percentage > 0): ?>
                <div class="offert sprite globo-<?php echo e(rand(1, 2)); ?>">%<?php echo e($product->discount_percentage); ?></div>
            <?php endif; ?>
            <img src="<?php echo e($product->getURLCover()); ?>" class="img-responsive"/>
            <h3><?php echo e($product->name); ?></h3>
            <h2>$0,000.00</h2>
        </div>
    </div>
</div>