
<?php $__env->startSection('body'); ?>
<nav>
    <ul class="menu sub-menu-productos">
        <li><a href="<?php echo e(url('populares')); ?>">POPULARES</a></li>
        <li><a href="<?php echo e(url('descuentos')); ?>">DESCUENTOS</a></li>
        <li><a href="<?php echo e(url('nuevos')); ?>">NUEVOS</a></li>
    </ul>
</nav>

<div class="row products">
    <?php foreach($products as $product): ?>
    <?php echo $__env->make('public.blocks.product',[
    'product' => $product
    ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endforeach; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>