<html>
    <head>
        <meta charset="UTF-8">
        <?php echo $__env->yieldContent('style'); ?>
    </head>
    <body>
        <div class="contenedor" style="min-width: 300px; max-width: 600px; border: 1px solid #284f53;margin: auto; text-align: center;font-family: Tahoma, Geneva, sans-serif;">
            <div class="cabeza" style="background-image: url('<?php echo e(asset('img/mail/bg-head-mail.jpg')); ?>');background-repeat: no-repeat;">
		<img src="<?php echo e(asset('img/mail/logo-glimglam.png')); ?>" alt="Logo Glim Glam" style="margin: 17px auto;">
            </div>
            
            <?php echo $__env->yieldContent('message'); ?>
            
            <div class="pie" style="background-color: #343233;padding: 5px 0;height: 40px;">
                    <div style="text-align: left;display: inline-block;float: left;margin-left: 10px;margin-top: 3px;">
                            <a href="<?php echo e(Config('app.social.fb')); ?>"><img src="<?php echo e(asset('img/mail/ico-facebook.png?').time()); ?>" target="_blank"></a>
                            <a href="<?php echo e(Config('app.social.ig')); ?>"><img src="<?php echo e(asset('img/mail/ico-instagram.png?'.time())); ?>" target="_blank"></a>
                            <a href="<?php echo e(Config('app.social.yt')); ?>"><img src="<?php echo e(asset('img/mail/ico-youtube.png?').time()); ?>" target="_blank"></a>
                            <a href="<?php echo e(Config('app.social.tw')); ?>"><img src="<?php echo e(asset('img/mail/ico-twitter.png?').time()); ?>" target="_blank"></a>
                    </div>
                    <div style="text-align: right;display: inline-block;float: right;margin-right: 10px;">
                            <img src="<?php echo e(asset('img/mail/logo-glimglam-footer.png')); ?>">
                    </div>
            </div>
        </div>
    </body>
</html>   
