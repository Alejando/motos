<?php $__env->startSection('style'); ?>
<style>
    .welcome {
        color:blue;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('message'); ?>
<div class="banner" style="padding: 18px 0;color: #fefefe;">
        <h2 style="text-transform: uppercase;margin: 40px auto;font-weight: 100;font-size: 40px;">
            <?php echo e($user->isMale() ? '¡BIENVENIDO':'¡BIENVENIDA'); ?> <span style=""><?php echo e($user->name); ?>!</span></h2>
</div>
<div class="mensaje" style="color: #003937; padding: 0 10%;">
        <p style="margin: 16px auto;font-size: 20px;margin-top: 30px;">Gracias por registrarte en <a href="http://bounce.mx" style="color: #003937;">Bounce</a></p>
        <p style="margin: 16px auto;">A partir de este momento podrás acceder nuestros productos y aprovechar la amplia oferta que tenemos para ti.</p>
        <hr>
        <a href="http://glimglam.mx/login" style="color: #fff; text-decoration: none;">
            <div style="margin: 10px auto 30px auto;border: 1px solid #3c9ba2;padding: 10px; width: 100px;background-color: #00bcb6;display: inline-block;">Iniciar Sesión</div>
        </a>
</div>
<div class="datos" style="background-color: #efefef; color: #003937;padding: 15px 30px;">
        <div style="width:49%;text-align: left;display: inline-block;vertical-align: top;">
                <h3 style="text-align: center;">Tus datos</h3>
                <p style="text-align: center;"><?php echo e($user->name); ?></p>
                <p style="text-align: center;">Usuario: <?php echo e($user->email); ?></p>
                <?php if($rawPassword): ?>
                    <p style="text-align: center;">Contraseña: <?php echo e($rawPassword); ?></p>
                <?php endif; ?>
                <p style="display: none; text-align: center;">Intereses:</p>
                <table style="display: none; text-align: center; font-size: 12px;" width="100%"> 
                    <tr>
                      <td style="padding: 7px 0;">Joyería</td>
                      <td style="padding: 7px 0;">Moda/Accesorios</td>
                    </tr>
                    <tr>
                      <td style="padding: 7px 0;">Electrónica</td>
                      <td style="padding: 7px 0;"></td>
                    </tr>
                    <tr>
                      <td style="padding: 7px 0;">Zapatos</td>
                      <td style="padding: 7px 0;"></td>
                    </tr>
                  </table>
        </div>
        <div style="width:49%;display: inline-block;vertical-align: top;">
                <h3 style="text-align: center;">Acerca de GlimGlam</h3>
                <a href="<?php echo e(asset("/#!video")); ?>" target="_blank"><img src="<?php echo e(asset('img/mail/btn-videoplayoverlay.png')); ?>" style="width: 90%;" ></a>
        </div>
</div>
<p style="font-size: 14px;"><span style="font-size: 22px; font-weight: bold;">Gracias,</span><br>Equipo GlimGlam</p>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('oculto'); ?>
Welcome! <span class="welcome">s<?php echo e($user->name); ?></span>
    <?php echo e($user->email); ?>

    <?php echo e(env('EMAIL_TEST_DEVELOPER')); ?>

    <img src="<?php echo e($message->embed("img/logo.png")); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mails.frames.common', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>