<link href="<?php echo e(asset('js/bower_components/normalize-css/normalize.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('js/bower_components/bootstrap/dist/css/bootstrap-theme.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('js/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('js/bower_components/jquery-ui/themes/smoothness/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('js/bower_components/owlcarousel/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('js/bower_components/owlcarousel/owl-carousel/owl.theme.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/web.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/web2.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/web-movil.css')); ?>" rel="stylesheet" type="text/css"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:light&v1' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:light&v1' rel='stylesheet' type='text/css'>
<link href="<?php echo e(asset('css/detalle.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/detalle-movil.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('js/bower_components/bootstrap3-dialog/dist/css/bootstrap-dialog.min.css')); ?>" rel="stylesheet" type="text/css"/>