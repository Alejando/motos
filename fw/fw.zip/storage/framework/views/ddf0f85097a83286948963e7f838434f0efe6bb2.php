Plantilla para correos en texto plano

<?php echo $__env->yieldContent('message'); ?>

Pie del correo