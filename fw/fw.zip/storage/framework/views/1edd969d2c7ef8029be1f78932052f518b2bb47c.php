<?php $__env->startSection('message'); ?>
    Welcome! <?php echo e($user->name); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('mails.frames.common-txt', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>