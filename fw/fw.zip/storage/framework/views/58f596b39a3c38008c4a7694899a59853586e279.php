<!--div class="banner">
    <img src="<?php echo e(asset('img/agassi.png')); ?>">
    <div>Andre Agassi</div>
</div-->

<div class="cajaestrella margentop30">
    <img src="<?php echo e(asset('img/agassi.png')); ?>" />
    <h2>Andre Agassi</h2>
</div>