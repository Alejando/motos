<?php

namespace DwSetpoint\Models;
class Content  extends \DevTics\LaravelHelpers\Model\ModelBase{
    
}