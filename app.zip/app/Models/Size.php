<?php
namespace DwSetpoint\Models;
class Size  extends \DevTics\LaravelHelpers\Model\ModelBase{
    
}