<?php

namespace DwSetpoint\Models;
class Color  extends \DevTics\LaravelHelpers\Model\ModelBase{
    
}