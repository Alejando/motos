<?php

namespace DwSetpoint\Events;

abstract class Event
{
    //
}
