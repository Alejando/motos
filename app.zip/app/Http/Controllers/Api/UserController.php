<?php

namespace DwSetpoint\Http\Controllers\Api;
class UserController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\User::class;
}