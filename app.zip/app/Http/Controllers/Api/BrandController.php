<?php


namespace DwSetpoint\Http\Controllers\Api;
class BrandController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Brand::class;
}