<?php

namespace DwSetpoint\Http\Controllers\Api;
class ColorController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Color::class;
}