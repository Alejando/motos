<?php

namespace DwSetpoint\Http\Controllers\Api;
class CategoryController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Category::class;
}