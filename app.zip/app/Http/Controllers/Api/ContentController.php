<?php

namespace DwSetpoint\Http\Controllers\Api;
class ContentController extends \DevTics\LaravelHelpers\Rest\ApiRestController {
    protected static $model = \DwSetpoint\Models\Content::class;
}