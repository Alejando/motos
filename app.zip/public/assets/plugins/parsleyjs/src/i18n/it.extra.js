window.ParsleyConfig = window.ParsleyConfig || {};
window.ParsleyConfig.i18n = window.ParsleyConfig.i18n || {};

window.ParsleyConfig.i18n.it = jQuery.extend(window.ParsleyConfig.i18n.it || {}, {
  dateiso: "Inserire una data valida (AAAA-MM-GG)."
});
