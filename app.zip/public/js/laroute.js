(function () {

    var laroute = (function () {

        var routes = {

            absolute: true,
            rootUrl: 'http://localhost/DW.setpoint/public/index.php',
            routes : [{"host":null,"methods":["GET","HEAD"],"uri":"api\/auction\/code\/{code}","name":"auction.getByCode","action":"DwSetpoint\Http\Controllers\Api\AuctionController@getByCode"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/content\/slug\/{slug}","name":"Content.slug","action":"DwSetpoint\Http\Controllers\Api\ContentController@slug"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/brand\/all-for-datatables","name":"brand.all-for-datatables","action":"DwSetpoint\Http\Controllers\Api\BrandController@getAllForDatatables"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/brand","name":"brand","action":"DwSetpoint\Http\Controllers\Api\BrandController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/brand\/create","name":"brand.create","action":"DwSetpoint\Http\Controllers\Api\BrandController@create"},{"host":null,"methods":["POST"],"uri":"api\/brand","name":"brand.store","action":"DwSetpoint\Http\Controllers\Api\BrandController@store"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/brand\/{brand}","name":"brand.show","action":"DwSetpoint\Http\Controllers\Api\BrandController@show"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/brand\/{brand}\/edit","name":"brand.edit","action":"DwSetpoint\Http\Controllers\Api\BrandController@edit"},{"host":null,"methods":["PUT","PATCH"],"uri":"api\/brand\/{brand}","name":"brand.update","action":"DwSetpoint\Http\Controllers\Api\BrandController@update"},{"host":null,"methods":["DELETE"],"uri":"api\/brand\/{brand}","name":"brand.destroy","action":"DwSetpoint\Http\Controllers\Api\BrandController@destroy"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/brand\/{id}\/relation\/{relation}","name":"brand.relation","action":"DwSetpoint\Http\Controllers\Api\BrandController@relation"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/color\/all-for-datatables","name":"color.all-for-datatables","action":"DwSetpoint\Http\Controllers\Api\ColorController@getAllForDatatables"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/color","name":"color","action":"DwSetpoint\Http\Controllers\Api\ColorController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/color\/create","name":"color.create","action":"DwSetpoint\Http\Controllers\Api\ColorController@create"},{"host":null,"methods":["POST"],"uri":"api\/color","name":"color.store","action":"DwSetpoint\Http\Controllers\Api\ColorController@store"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/color\/{color}","name":"color.show","action":"DwSetpoint\Http\Controllers\Api\ColorController@show"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/color\/{color}\/edit","name":"color.edit","action":"DwSetpoint\Http\Controllers\Api\ColorController@edit"},{"host":null,"methods":["PUT","PATCH"],"uri":"api\/color\/{color}","name":"color.update","action":"DwSetpoint\Http\Controllers\Api\ColorController@update"},{"host":null,"methods":["DELETE"],"uri":"api\/color\/{color}","name":"color.destroy","action":"DwSetpoint\Http\Controllers\Api\ColorController@destroy"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/color\/{id}\/relation\/{relation}","name":"color.relation","action":"DwSetpoint\Http\Controllers\Api\ColorController@relation"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/address\/all-for-datatables","name":"address.all-for-datatables","action":"DwSetpoint\Http\Controllers\Api\AddressController@getAllForDatatables"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/address","name":"address","action":"DwSetpoint\Http\Controllers\Api\AddressController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/address\/create","name":"address.create","action":"DwSetpoint\Http\Controllers\Api\AddressController@create"},{"host":null,"methods":["POST"],"uri":"api\/address","name":"address.store","action":"DwSetpoint\Http\Controllers\Api\AddressController@store"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/address\/{address}","name":"address.show","action":"DwSetpoint\Http\Controllers\Api\AddressController@show"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/address\/{address}\/edit","name":"address.edit","action":"DwSetpoint\Http\Controllers\Api\AddressController@edit"},{"host":null,"methods":["PUT","PATCH"],"uri":"api\/address\/{address}","name":"address.update","action":"DwSetpoint\Http\Controllers\Api\AddressController@update"},{"host":null,"methods":["DELETE"],"uri":"api\/address\/{address}","name":"address.destroy","action":"DwSetpoint\Http\Controllers\Api\AddressController@destroy"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/address\/{id}\/relation\/{relation}","name":"address.relation","action":"DwSetpoint\Http\Controllers\Api\AddressController@relation"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/size\/all-for-datatables","name":"size.all-for-datatables","action":"DwSetpoint\Http\Controllers\Api\SizeController@getAllForDatatables"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/size","name":"size","action":"DwSetpoint\Http\Controllers\Api\SizeController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/size\/create","name":"size.create","action":"DwSetpoint\Http\Controllers\Api\SizeController@create"},{"host":null,"methods":["POST"],"uri":"api\/size","name":"size.store","action":"DwSetpoint\Http\Controllers\Api\SizeController@store"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/size\/{size}","name":"size.show","action":"DwSetpoint\Http\Controllers\Api\SizeController@show"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/size\/{size}\/edit","name":"size.edit","action":"DwSetpoint\Http\Controllers\Api\SizeController@edit"},{"host":null,"methods":["PUT","PATCH"],"uri":"api\/size\/{size}","name":"size.update","action":"DwSetpoint\Http\Controllers\Api\SizeController@update"},{"host":null,"methods":["DELETE"],"uri":"api\/size\/{size}","name":"size.destroy","action":"DwSetpoint\Http\Controllers\Api\SizeController@destroy"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/size\/{id}\/relation\/{relation}","name":"size.relation","action":"DwSetpoint\Http\Controllers\Api\SizeController@relation"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/category\/all-for-datatables","name":"category.all-for-datatables","action":"DwSetpoint\Http\Controllers\Api\CategoryController@getAllForDatatables"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/category","name":"category","action":"DwSetpoint\Http\Controllers\Api\CategoryController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/category\/create","name":"category.create","action":"DwSetpoint\Http\Controllers\Api\CategoryController@create"},{"host":null,"methods":["POST"],"uri":"api\/category","name":"category.store","action":"DwSetpoint\Http\Controllers\Api\CategoryController@store"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/category\/{category}","name":"category.show","action":"DwSetpoint\Http\Controllers\Api\CategoryController@show"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/category\/{category}\/edit","name":"category.edit","action":"DwSetpoint\Http\Controllers\Api\CategoryController@edit"},{"host":null,"methods":["PUT","PATCH"],"uri":"api\/category\/{category}","name":"category.update","action":"DwSetpoint\Http\Controllers\Api\CategoryController@update"},{"host":null,"methods":["DELETE"],"uri":"api\/category\/{category}","name":"category.destroy","action":"DwSetpoint\Http\Controllers\Api\CategoryController@destroy"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/category\/{id}\/relation\/{relation}","name":"category.relation","action":"DwSetpoint\Http\Controllers\Api\CategoryController@relation"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/content\/all-for-datatables","name":"content.all-for-datatables","action":"DwSetpoint\Http\Controllers\Api\ContentController@getAllForDatatables"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/content","name":"content","action":"DwSetpoint\Http\Controllers\Api\ContentController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/content\/create","name":"content.create","action":"DwSetpoint\Http\Controllers\Api\ContentController@create"},{"host":null,"methods":["POST"],"uri":"api\/content","name":"content.store","action":"DwSetpoint\Http\Controllers\Api\ContentController@store"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/content\/{content}","name":"content.show","action":"DwSetpoint\Http\Controllers\Api\ContentController@show"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/content\/{content}\/edit","name":"content.edit","action":"DwSetpoint\Http\Controllers\Api\ContentController@edit"},{"host":null,"methods":["PUT","PATCH"],"uri":"api\/content\/{content}","name":"content.update","action":"DwSetpoint\Http\Controllers\Api\ContentController@update"},{"host":null,"methods":["DELETE"],"uri":"api\/content\/{content}","name":"content.destroy","action":"DwSetpoint\Http\Controllers\Api\ContentController@destroy"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/content\/{id}\/relation\/{relation}","name":"content.relation","action":"DwSetpoint\Http\Controllers\Api\ContentController@relation"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/user\/all-for-datatables","name":"user.all-for-datatables","action":"DwSetpoint\Http\Controllers\Api\UserController@getAllForDatatables"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/user","name":"user","action":"DwSetpoint\Http\Controllers\Api\UserController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/user\/create","name":"user.create","action":"DwSetpoint\Http\Controllers\Api\UserController@create"},{"host":null,"methods":["POST"],"uri":"api\/user","name":"user.store","action":"DwSetpoint\Http\Controllers\Api\UserController@store"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/user\/{user}","name":"user.show","action":"DwSetpoint\Http\Controllers\Api\UserController@show"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/user\/{user}\/edit","name":"user.edit","action":"DwSetpoint\Http\Controllers\Api\UserController@edit"},{"host":null,"methods":["PUT","PATCH"],"uri":"api\/user\/{user}","name":"user.update","action":"DwSetpoint\Http\Controllers\Api\UserController@update"},{"host":null,"methods":["DELETE"],"uri":"api\/user\/{user}","name":"user.destroy","action":"DwSetpoint\Http\Controllers\Api\UserController@destroy"},{"host":null,"methods":["GET","HEAD"],"uri":"api\/user\/{id}\/relation\/{relation}","name":"user.relation","action":"DwSetpoint\Http\Controllers\Api\UserController@relation"},{"host":null,"methods":["GET","HEAD"],"uri":"home","name":null,"action":"DwSetpoint\Http\Controllers\HomeController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"admin","name":null,"action":"DwSetpoint\Http\Controllers\AdminCtrl@index"},{"host":null,"methods":["GET","HEAD"],"uri":"pages\/admin\/{view}.html","name":"page","action":"DwSetpoint\Http\Controllers\PagesCtrl@admin"},{"host":null,"methods":["GET","HEAD"],"uri":"\/","name":null,"action":"DwSetpoint\Http\Controllers\HomeController@index"},{"host":null,"methods":["GET","HEAD"],"uri":"login","name":null,"action":"DwSetpoint\Http\Controllers\Auth\AuthController@showLoginForm"},{"host":null,"methods":["POST"],"uri":"login","name":null,"action":"DwSetpoint\Http\Controllers\Auth\AuthController@login"},{"host":null,"methods":["GET","HEAD"],"uri":"logout","name":null,"action":"DwSetpoint\Http\Controllers\Auth\AuthController@logout"},{"host":null,"methods":["GET","HEAD"],"uri":"register","name":null,"action":"DwSetpoint\Http\Controllers\Auth\AuthController@showRegistrationForm"},{"host":null,"methods":["POST"],"uri":"register","name":null,"action":"DwSetpoint\Http\Controllers\Auth\AuthController@register"},{"host":null,"methods":["GET","HEAD"],"uri":"password\/reset\/{token?}","name":null,"action":"DwSetpoint\Http\Controllers\Auth\PasswordController@showResetForm"},{"host":null,"methods":["POST"],"uri":"password\/email","name":null,"action":"DwSetpoint\Http\Controllers\Auth\PasswordController@sendResetLinkEmail"},{"host":null,"methods":["POST"],"uri":"password\/reset","name":null,"action":"DwSetpoint\Http\Controllers\Auth\PasswordController@reset"}],
            prefix: '',

            route : function (name, parameters, route) {
                route = route || this.getByName(name);

                if ( ! route ) {
                    return undefined;
                }

                return this.toRoute(route, parameters);
            },

            url: function (url, parameters) {
                parameters = parameters || [];

                var uri = url + '/' + parameters.join('/');

                return this.getCorrectUrl(uri);
            },

            toRoute : function (route, parameters) {
                var uri = this.replaceNamedParameters(route.uri, parameters);
                var qs  = this.getRouteQueryString(parameters);

                return this.getCorrectUrl(uri + qs);
            },

            replaceNamedParameters : function (uri, parameters) {
                uri = uri.replace(/\{(.*?)\??\}/g, function(match, key) {
                    if (parameters.hasOwnProperty(key)) {
                        var value = parameters[key];
                        delete parameters[key];
                        return value;
                    } else {
                        return match;
                    }
                });

                // Strip out any optional parameters that were not given
                uri = uri.replace(/\/\{.*?\?\}/g, '');

                return uri;
            },

            getRouteQueryString : function (parameters) {
                var qs = [];
                for (var key in parameters) {
                    if (parameters.hasOwnProperty(key)) {
                        qs.push(key + '=' + parameters[key]);
                    }
                }

                if (qs.length < 1) {
                    return '';
                }

                return '?' + qs.join('&');
            },

            getByName : function (name) {
                for (var key in this.routes) {
                    if (this.routes.hasOwnProperty(key) && this.routes[key].name === name) {
                        return this.routes[key];
                    }
                }
            },

            getByAction : function(action) {
                for (var key in this.routes) {
                    if (this.routes.hasOwnProperty(key) && this.routes[key].action === action) {
                        return this.routes[key];
                    }
                }
            },

            getCorrectUrl: function (uri) {
                var url = this.prefix + '/' + uri.replace(/^\/?/, '');

                if(!this.absolute)
                    return url;

                return this.rootUrl.replace('/\/?$/', '') + url;
            }
        };

        var getLinkAttributes = function(attributes) {
            if ( ! attributes) {
                return '';
            }

            var attrs = [];
            for (var key in attributes) {
                if (attributes.hasOwnProperty(key)) {
                    attrs.push(key + '="' + attributes[key] + '"');
                }
            }

            return attrs.join(' ');
        };

        var getHtmlLink = function (url, title, attributes) {
            title      = title || url;
            attributes = getLinkAttributes(attributes);

            return '<a href="' + url + '" ' + attributes + '>' + title + '</a>';
        };

        return {
            // Generate a url for a given controller action.
            // laroute.action('HomeController@getIndex', [params = {}])
            action : function (name, parameters) {
                parameters = parameters || {};

                return routes.route(name, parameters, routes.getByAction(name));
            },

            // Generate a url for a given named route.
            // laroute.route('routeName', [params = {}])
            route : function (route, parameters) {
                parameters = parameters || {};

                return routes.route(route, parameters);
            },

            // Generate a fully qualified URL to the given path.
            // laroute.route('url', [params = {}])
            url : function (route, parameters) {
                parameters = parameters || {};

                return routes.url(route, parameters);
            },

            // Generate a html link to the given url.
            // laroute.link_to('foo/bar', [title = url], [attributes = {}])
            link_to : function (url, title, attributes) {
                url = this.url(url);

                return getHtmlLink(url, title, attributes);
            },

            // Generate a html link to the given route.
            // laroute.link_to_route('route.name', [title=url], [parameters = {}], [attributes = {}])
            link_to_route : function (route, title, parameters, attributes) {
                var url = this.route(route, parameters);

                return getHtmlLink(url, title, attributes);
            },

            // Generate a html link to the given controller action.
            // laroute.link_to_action('HomeController@getIndex', [title=url], [parameters = {}], [attributes = {}])
            link_to_action : function(action, title, parameters, attributes) {
                var url = this.action(action, parameters);

                return getHtmlLink(url, title, attributes);
            }

        };

    }).call(this);

    /**
     * Expose the class either via AMD, CommonJS or the global object
     */
    if (typeof define === 'function' && define.amd) {
        define(function () {
            return laroute;
        });
    }
    else if (typeof module === 'object' && module.exports){
        module.exports = laroute;
    }
    else {
        window.laroute = laroute;
    }

}).call(this);

